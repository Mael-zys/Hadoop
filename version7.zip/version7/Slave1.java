import java.util.Map;
import java.util.Arrays;
import java.util.*;
import java.util.Set;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.io.File;
import java.io.FileOutputStream;

public class Slave1{
    private static int linecount =0;
    private static int value =0;

public static void Read_Print(String strFile,String txt){
        try {
            File file = new File(strFile);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                Read_Print_Line(strLine,txt);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

public static void mapping(String str, String master){
        int i = str.lastIndexOf("S");
        String num=str.substring(i+1,str.length()-4);
	String txt="/tmp/ie/maps/UM"+ num+".txt";        
	Read_Print(str,txt);
        String dest="Desktop/maps/";
        sendBack(txt,dest,0,master);
        //"./UM"+ num+".txt"
    }

public static void Read_Print_Line(String line,String txt){
	
	try{
		line=line.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+"," ");
		line = line.replaceAll("^$", " ");
        	String[] command = line.split(" ");
		FileOutputStream os = new FileOutputStream(new File(txt), true);
                for(int i=0;i<command.length;i++){
                        String word=command[i];
			DOWriteTxt(txt, word+" 1",os);
                }
		os.close();
	} catch(Exception e){
		e.printStackTrace();
	}
    }
public static void sendBack(String depart,String dest,int mode,String master){
        try{
            ProcessBuilder pb=new ProcessBuilder("scp",depart,master+":"+dest);
            if(mode==0){
                pb=new ProcessBuilder("scp",depart,master+":"+dest);
            }
            else if(mode==1){
                pb=new ProcessBuilder("scp","-r",depart,master+":"+dest);
            }
            Process process=pb.start();
            process.waitFor();
        }catch(Exception e){
		    e.printStackTrace();
		}
    }
    public static void mapLine(String line, String key){
		line=line.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+"," ");
		line = line.replaceAll("^$", " ");
        	String[] command = line.split(" ");            
                String word=command[0];
		if(word.equals(key)){	
				
		}


    }


    public static void DOWriteTxt(String file, String txt, FileOutputStream os) {
      try {
       
       os.write((txt + "\n").getBytes());


      } catch (Exception e) {
       e.printStackTrace();
      }
    }
    
	public static void Read_Shuffle(String strFile,String txt,String key){
		try {
		    File file = new File(strFile);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null;
		FileOutputStream os = new FileOutputStream(new File(txt), true);
		    while(null != (strLine = bufferedReader.readLine())){
		        Read_Shuffle_Line(strLine,txt,key,os);
		    }
os.close();
		}catch(Exception e){
		    e.printStackTrace();
		}
	    }
	public static void Read_Shuffle_Line(String line,String txt,String key,FileOutputStream os){
		
		try{
			line=line.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+"," ");
			line = line.replaceAll("^$", " ");
			String[] command= line.split(" ");
		        String word=command[0];
			if(word.equals(key)){
			DOWriteTxt(txt, word+" 1",os);
			value++;
			}
		        
		} catch(Exception e){
			e.printStackTrace();
		}
	    }
    public static void shuffling(String[] arg){
	try{        
		int len=arg.length;
		String word=arg[1];
		String txt=arg[2];
		String num=arg[3];
		for(int i=4;i<=len-1;i++){
		    Read_Shuffle(arg[i],txt,word);
		}
		int i = txt.lastIndexOf("S");
		//String num=txt.substring(i+2,txt.length()-4);
		String dest="/tmp/ie/reduces/RM"+num+".txt";
		FileOutputStream os1 = new FileOutputStream(new File(dest), true);
		DOWriteTxt(dest, word+" "+value,os1);
		os1.close();
		//sendBack(dest,"Desktop/reduces/",0);
	} catch(Exception e){
		e.printStackTrace();
	}
	
    }

    public static void reducing(String master){
        /*
	String word=arg[1];
        String file=arg[2];
        String txt=arg[3];
        readFileLine(file);
        DOWriteTxt(txt, word+" "+linecount);
	*/
	sendBack("/tmp/ie/reduces/","Desktop/",1,master);
    }
    public static void main(String[] arg)throws IOException{
	 try{        
		if (arg[0].equals("0")){
		    mapping(arg[1],arg[2]);
		    System.out.println("Map over");
		 }
		 if (arg[0].equals("1")){
		    shuffling(arg);
		    System.out.println("Shuffle over");
		 }
		 if (arg[0].equals("2")){
		    reducing(arg[1]);
		    System.out.println("Reduce over");
		 }
         }catch(Exception e){
		e.printStackTrace();
		System.out.println("error");
	}
    }
}

