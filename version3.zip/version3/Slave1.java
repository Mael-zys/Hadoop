import java.util.Map;
import java.util.Arrays;
import java.util.*;
import java.util.Set;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.io.File;
import java.io.FileOutputStream;

public class Slave1{
    private static Map<String, Integer> wordMap=new HashMap<String, Integer>();
    private static ArrayList<String> wordList=new ArrayList<String>();
    private static int linecount =0;
    private static int value =0;

    public static void readFileLine(String strFile){
        try {
            File file = new File(strFile);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                mapLine(strLine);
                linecount++;
				/* System.out.println(strLine);
				String[] command = strLine.split(" ");
				System.out.println("line "+command[0]);  */
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

public static void sendBack(String depart,String dest,int mode){
        try{
            ProcessBuilder pb=new ProcessBuilder("scp",depart,"ie@192.168.1.199:"+dest);
            if(mode==0){
                pb=new ProcessBuilder("scp",depart,"ie@192.168.1.199:"+dest);
            }
            else if(mode==1){
                pb=new ProcessBuilder("scp","-r",depart,"ie@192.168.1.199:"+dest);
            }
            Process process=pb.start();
            process.waitFor();
        }catch(Exception e){
		    e.printStackTrace();
		}
    }
    public static void mapLine(String line){
		line=line.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5\'-]+"," ");
		line = line.replaceAll("^$", " ");
        String[] command = line.split(" ");
                for(int i=0;i<command.length;i++){
                        String word=command[i];
                        wordList.add(word);
                        //System.out.println(word+"\n");
                        //System.out.println("word : "+word);
                        //DOWriteTxt(txt, word+" 1");
                        /*if(!wordMap.containsKey(word))
                            wordMap.put(word,1);
                        else {
                            int nombre=wordMap.get(word);
                            nombre++;
                            wordMap.put(word,nombre);
                        }*/
                }
    }

    public static void printUsers() {
		for (String key : wordMap.keySet()) {
			System.out.println(key+" "+wordMap.get(key));
			//System.out.println("Value = " + wordMap.get(key));
		}
	}


    public static void DOWriteTxt(String file, String txt) {
      try {
       FileOutputStream os = new FileOutputStream(new File(file), true);
       os.write((txt + "\n").getBytes());
       value++;
      } catch (Exception e) {
       e.printStackTrace();
      }
    }
    public static void sort(){
        Set set=wordMap.keySet();
        Object[] arr=set.toArray();
        Arrays.sort(arr);
        int length=arr.length;
        for(int i=0;i<length;i++){
            for(int j=0;j<length-1-i;j++)
            {
                if(wordMap.get(arr[j])<wordMap.get(arr[j+1]))
                {
                    Object temp=arr[j+1];
                    arr[j+1]=arr[j];
                    arr[j]=temp;
                }
            }
        }
        for (Object key:arr) {
			System.out.println(key+" "+wordMap.get(key));
		}
    }
    public static void mapping(String str){
        int i = str.lastIndexOf("S");
        String num=str.substring(i+1,str.length()-4);
        readFileLine(str);
String txt="/tmp/ie/maps/UM"+ num+".txt";
        for(int j =0;j<wordList.size();j++){
                String word=wordList.get(j);
                DOWriteTxt(txt, word+" 1");
        }
        String dest="Desktop/maps/";
        sendBack(txt,dest,0);
        //"./UM"+ num+".txt"
    }

    public static void shuffling(String[] arg){
        int len=arg.length;
        String word=arg[1];
        String txt=arg[2];
        for(int i=3;i<=len-1;i++){
            readFileLine(arg[i]);
        }
        for(int j=0;j<wordList.size();j++){
            if (word.equals(wordList.get(j))){
                DOWriteTxt(txt, word+" 1");
            }
        }
        int i = txt.lastIndexOf("S");
        String num=txt.substring(i+2,txt.length()-4);
        String dest="/tmp/ie/reduces/RM"+num+".txt";
        linecount=0;
        readFileLine(txt);
        DOWriteTxt(dest, word+" "+linecount);
sendBack(dest.substring(0,dest.lastIndexOf("/")+1),"Desktop/",1);
    }

    /*public static void reducing(String[] arg){
        String word=arg[1];
        String file=arg[2];
        String txt=arg[3];
        readFileLine(file);
        DOWriteTxt(txt, word+" "+linecount);
    }*/
    public static void main(String[] arg)throws IOException{
	 try{        
		if (arg[0].equals("0")){
		    mapping(arg[1]);
		    System.out.println("Map over");
		 }
		 if (arg[0].equals("1")){
		    shuffling(arg);
		    System.out.println("Shuffle over");
		 }/*
		 if (arg[0].equals("2")){
		    reducing(arg);
		    System.out.println("Reduce over");
		 }*/
         }catch(Exception e){
		e.printStackTrace();
		System.out.println("error");
	}
    }
}

