import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;

public class MyThread2 implements Runnable
{
    public ArrayList<String> name=new ArrayList<String>();

    public void setName(ArrayList<String> name)
    {
        this.name = name;
    }
    public void run()
    {
        try{ProcessBuilder pb = new ProcessBuilder(name);
        Process p=pb.start();
        //System.out.println(name.get(4));
	p.waitFor();
	p.destroy();
	//interrupt();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
    
    public static void main(String[] args)
    {
	try{        
		for (int i=0;i<5;i++){
		    MyThread2 myThread = new MyThread2();
		    ArrayList<String> name=new ArrayList<String>();
		    name.add("java");
		    name.add("-jar");
		    name.add("Slave.jar");
		    name.add("0");
		    name.add("S"+i+".txt");
		    myThread.setName(name);
		    Thread thread = new Thread(myThread);
		    thread.start();
			thread.join();
		}
	} catch(Exception e){;}
    }
}
