import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.io.File;
import java.io.BufferedReader;
import java.io.BufferedWriter;
public class MyThread implements Runnable
{
    public String name;
    public String print;
    public int i;
    public int slaveCount;
    public void split(String name, int i, int slaveCount)
    {
        this.name = name;  //filename, i, slaveCount
	this.i=i;
	this.slaveCount=slaveCount;
    }


    public void run()
    {
        try {
		    File file = new File(name);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine;
		    FileWriter fw = new FileWriter("S"+i+".txt");
		    int row_number=0;
		    while ((strLine = bufferedReader.readLine()) != null) {
			if(row_number%slaveCount==i && strLine!="^$" && strLine!="\n" && strLine!="\r" ){
				
				fw.append(strLine + "\r\n");			
			}
			row_number=row_number+1;
		    }
		    fw.close();
        }catch(Exception e){
        e.printStackTrace();
        }
    }

    public static void main(String[] args)
    {
	try{        
		for (int i=0;i<4;i++){
		    MyThread myThread = new MyThread();
		 
		    myThread.split("README.txt",i,4);
		    Thread thread = new Thread(myThread);
		    thread.start();
		}
	} catch(Exception e){;}
    }
    
}
