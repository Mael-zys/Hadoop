import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;

public class MyThread2 implements Runnable
{
    public ArrayList<String> name=new ArrayList<String>();

    public String print;
    public void setName(ArrayList<String> name)
    {
        this.name = name;
    }

    public void setPrint(String name)
    {
        this.print = name;
    }
    public void run()
    {
        try{ProcessBuilder pb = new ProcessBuilder(name);
        Process p=pb.start();
        
	p.waitFor();
	System.out.println(print);
	p.destroy();
	//interrupt();
        }catch(Exception e){
        e.printStackTrace();
        }
    }
    
}
