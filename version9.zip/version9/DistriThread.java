import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;

public class DistriThread implements Runnable
{
    public String name;
    public String ip;
    public String print;
    int ii;
    public void setName(String name,String ip,int ii)
    {
        this.name = name;
	this.ip=ip;
	this.ii=ii;
    }

    public void setPrint(String name)
    {
        this.print = name;
    }
    public void run()
    {
	try{        
			ProcessBuilder pb = new ProcessBuilder("ssh",name+"@"+ip,"pkill","-u",name);
			Process process = pb.start();
			//System.out.println("distribute file to slave "+ii);
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("ssh",name+"@"+ip,"rm","-rf","/tmp/ie/");
			process = pb.start();
			//System.out.println("distribute file to slave "+ii);
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		  	pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/");
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("scp","Slave.jar",name+"@"+ip+":/tmp/ie/");
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/splits/");
			process = pb.start();
			try {
				process.waitFor();//lave 0 shuffle word : 0 Car

				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("scp","S"+ii+".txt",name+"@"+ip+":/tmp/ie/splits/");
			process = pb.start();
			try {
				process.waitFor();
				System.out.println(print);
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/maps/");
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/reduces/");
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
				byte[] re=new byte[1024];
				while(isI.read(re)!=-1){
					System.out.println(new String(re));
				}
			} catch(Exception e) {
					e.printStackTrace();
			}
	}catch(Exception e){e.printStackTrace();}
    }
    
}

