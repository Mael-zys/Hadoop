import  java.lang.Object;
import java.lang.ProcessBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
//import java.io.TimeUnit;


public class Master{

	public static String ReadFile;
	public static int slaveCount = 0;
	public static ArrayList<String> slaveList=new ArrayList<String>();
	public static String IPmaster;
	public static String masterName;
	private static Map<String, Integer> wordMap=new HashMap<String, Integer>();
	public static ArrayList<Thread> slaveThread=new ArrayList<Thread>();
	public static ArrayList<Thread> splitThread=new ArrayList<Thread>();
	public static ArrayList<Thread> distriThread=new ArrayList<Thread>();


	public static void readWord(String strFile){
		try {
		    File file = new File(strFile);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null;
		    while(null != (strLine = bufferedReader.readLine())){
		        if(strLine!="^$" && strLine!="\n" && strLine!="\r") 
			{
				String[] command = strLine.split(" ");
		                String word=command[0];
		                wordMap.put(word,0);
		        }
		    }
		}catch(Exception e){
		    e.printStackTrace();
		}
	 }

	    public static void readFileLine(String strFile, int s){
		try {

		    for (int i=0;i<s;i++){
		            MyThread myThread = new MyThread();		    
			    myThread.split(strFile,i,s);			    
			    Thread thread = new Thread(myThread);
			    splitThread.add(thread);
			    splitThread.get(i).start();
				
			}
			
			for (int i=0;i<s;i++){
                            Thread thread = splitThread.get(i);
			    while(thread.isAlive()) {;}
			}
			
		}
		catch(Exception e){
		    e.printStackTrace();
		}
	    }

	public static void slaveOn(String fileName) throws IOException {
		//get master's IP
		try{
			ProcessBuilder pb0 = new ProcessBuilder("ifconfig");
			Process process0 = pb0.start();
			process0.waitFor();
			InputStream isI=process0.getInputStream();
			byte[] re=new byte[1024];
			while(isI.read(re)!=-1){
				//System.out.println(new String(re));
				String read=new String(re);
				int index=read.indexOf("inet ");
				if(index!=-1) {
					int index1=read.indexOf("  netmask");
					IPmaster=read.substring(index+5,index1);
					//System.out.println("master's IP is "+IPmaster);
					break;
				}
			}
		if(IPmaster==null) {System.out.println("master is offline"); return;}
			InputStream IsE=process0.getErrorStream();
		}catch(Exception e){
			e.printStackTrace();
		}

		//get master's name
		try{
			ProcessBuilder pb0 = new ProcessBuilder("who");
			Process process0 = pb0.start();
			process0.waitFor();
			InputStream isI=process0.getInputStream();
			byte[] re=new byte[1024];
			int i=0;
			while(isI.read(re)!=-1){
				if(i!=0) break;
				//System.out.println(new String(re));
				String read=new String(re);
				int index=read.indexOf(" ");
				masterName=read.substring(0,index);
				//System.out.println("master's name is "+masterName);
				i++;
			}
		if(masterName==null) {System.out.println("master error: can't get master's name"); return;}
			InputStream IsE=process0.getErrorStream();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println("master's name: "+masterName+" and its IP: "+IPmaster);


		//if slave is online
		try {
		    File file = new File(fileName);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null;
		    while(null != (strLine = bufferedReader.readLine())){
		        String[] sla = strLine.split(" ");
			ProcessBuilder pb0 = new ProcessBuilder("nmap",sla[1]);
			Process process0 = pb0.start();
			process0.waitFor();
			InputStream isI=process0.getInputStream();
			byte[] re=new byte[1024];
			while(isI.read(re)!=-1){
				//System.out.println(new String(re));
				String read=new String(re);
				//String[] slave = read.split(" ");
				int index=read.indexOf("22/tcp");
				if(index!=-1) {
					slaveList.add(strLine);
					slaveCount++;
					break;
				}
			}
			InputStream IsE=process0.getErrorStream();

		    }
		}catch(Exception e){
		    e.printStackTrace();
		}

		if(slaveCount==0) {
			System.out.println("no slave online");
			return;
		}
		

		System.out.println("number of slave online: "+slaveCount);
		readFileLine(ReadFile, slaveCount);
		


		ProcessBuilder pb1 = new ProcessBuilder("rm","-rf","maps/");
			Process process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		pb1 = new ProcessBuilder("mkdir","/home/ie/Desktop/maps/");
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		pb1 = new ProcessBuilder("rm","-rf","/home/ie/Desktop/reduces/");
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		pb1 = new ProcessBuilder("mkdir","/home/ie/Desktop/reduces/");
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		for(int ii=0;ii<slaveList.size();ii++){
			String[] slave=slaveList.get(ii).split(" ");
			String name=slave[0];
			String ip=slave[1];
			try {
		            DistriThread myThread = new DistriThread();		    
			    myThread.setName(name,ip,ii);	
			
			    myThread.setPrint("distribute file to slave "+ii);		    
			    Thread thread = new Thread(myThread);
			    distriThread.add(thread);
			    distriThread.get(ii).start();
			}
			catch(Exception e){
			    e.printStackTrace();
			}
			
		}
		for (int i=0;i<slaveCount;i++){
                            Thread thread = distriThread.get(i);
			    while(thread.isAlive()) {;}
		}
	}


	

	public static void maping(){
		try{


			for (int i=0;i<slaveCount;i++){
		            MyThread2 myThread = new MyThread2();

			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    name.add("ssh");
			    name.add(name_slave+"@"+ip);
			    name.add("/usr/java/jdk1.8.0_231/bin/java");
			    name.add("-jar");
			    name.add("/tmp/ie/Slave.jar");
				name.add("0");
				name.add("/tmp/ie/splits/S"+i+".txt");
				name.add(masterName+"@"+IPmaster);
			    myThread.setName(name);
			    myThread.setPrint("mapping slave "+i);
			    Thread thread = new Thread(myThread);
			    slaveThread.add(thread);
			    //thread.start();
				slaveThread.get(i).start();
				//System.out.println("mapping slave "+i);
				//thread.join();
			}
			//Thread.currentThread().sleep(5000);
			for (int i=0;i<slaveCount;i++){
                            Thread thread = slaveThread.get(i);
			    while(thread.isAlive()) {;}
			}
			Thread.currentThread().sleep(200);
			for(int i=0;i<slaveCount;i++)
				readWord("./maps/UM"+i+".txt");

		}catch(Exception e){
			e.printStackTrace();
		}
	}

        public static ArrayList<Thread> wordThread=new ArrayList<Thread>();
	public static void shuffling() throws IOException{
		//TimeUnit.SECONDS.sleep(1);
		try{
			
			ArrayList<ProcessBuilder> pb=new ArrayList<ProcessBuilder>();
			ArrayList<Process> p=new ArrayList<Process>();
			for(int ii=0;ii<slaveList.size();ii++){
				String[] slave=slaveList.get(ii).split(" ");
				String name=slave[0];
				String ip=slave[1];
					pb.add(new ProcessBuilder("scp","-r","maps/",name+"@"+ip+":/tmp/ie/"));
					try {
						p.add(pb.get(ii).start());
						//p.get(jj).waitFor();
						System.out.println("send slave "+ii+" all texts ");
						InputStream isI=p.get(ii).getInputStream();
						isI.read();
						InputStream IsE=p.get(ii).getErrorStream();
					} catch(Exception e) {
							e.printStackTrace();
					}

			}

			for(int ii=0;ii<slaveList.size();ii++){
				try {
					p.get(ii).waitFor();
				} catch(Exception e) {
						e.printStackTrace();
				}
			}
		} catch(Exception e){e.printStackTrace();}

		try{
			Set set=wordMap.keySet();
			Object[] arr=set.toArray();
			int wait_time=0;
			for (int i=0;i<wordMap.size();i++){
				Thread.currentThread().sleep(20);
			    if( i==600) wait_time = 20;
 			    if( i==1000) wait_time = 0;
			    if( i==1500) wait_time = 20;
				if(i>=2000 && i%500==0) wait_time=0;
				if(i>=2000 && i%1000==0) wait_time=20;

			    Thread.currentThread().sleep(wait_time);
			    if(i>=3000 && i%1000==250 ) Thread.currentThread().sleep(500);


			    MyThread2 myThread = new MyThread2();
			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i%slaveCount).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    	name.add("ssh");
				name.add(name_slave+"@"+ip);
				name.add("/usr/java/jdk1.8.0_231/bin/java");
				name.add("-jar");
				name.add("/tmp/ie/Slave.jar");
				name.add("1");
				name.add(arr[i].toString());

				name.add("/tmp/ie/maps/SM"+i+".txt");
				name.add(String.valueOf(i%slaveCount));
			for (int jj=0;jj<slaveList.size();jj++){

				name.add("/tmp/ie/maps/UM"+jj+".txt");
			}
			    myThread.setName(name);
				myThread.setPrint("slave "+i%slaveCount+" shuffle word "+i+": "+arr[i].toString());
			    Thread thread = new Thread(myThread);
			    wordThread.add(thread);
			    wordThread.get(i).start();

			}

		}catch(Exception e){
			e.printStackTrace();
		}
	}

//pb.add(new ProcessBuilder("ssh",name+"@"+ip,"/usr/java/jdk1.8.0_231/bin/java","-jar","/tmp/ie/Slave.jar","2",masterName+"@"+IPmaster));
	public static ArrayList<Thread> reduceThread=new ArrayList<Thread>();
	public static void reduces(){
		try{
			for (int i=0;i<slaveCount;i++){
		            MyThread2 myThread = new MyThread2();
			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    name.add("ssh");
			    name.add(name_slave+"@"+ip);
			    name.add("/usr/java/jdk1.8.0_231/bin/java");
			    name.add("-jar");
			    name.add("/tmp/ie/Slave.jar");
				name.add("2");
				name.add(masterName+"@"+IPmaster);
			    myThread.setName(name);
			    myThread.setPrint("reduce slave "+i);
			    Thread thread = new Thread(myThread);
			    reduceThread.add(thread);
			    reduceThread.get(i).start();
			}
			for (int i=0;i<slaveCount;i++){
                            Thread thread = reduceThread.get(i);
			    while(thread.isAlive()) {;}
			}
			Thread.currentThread().sleep(200);

		}catch(Exception e){
			e.printStackTrace();
		}

	}


	public static void readFileLine1(String strFile){
        try {
            File file = new File(strFile);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                mapLine1(strLine);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    	public static void mapLine1(String line){
        	String[] command = line.split(" ");
		String key=command[0];
		int value=Integer.parseInt(command[1]);
                wordMap.put(key,value);
    	}

	public static void sort(){
		try{
			//Thread.currentThread().sleep(5000);
			wordMap.clear();
			for(int ii=0;ii<slaveList.size();ii++){
				readFileLine1("reduces/RM"+ii+".txt");
			}
			Set set=wordMap.keySet();
			Object[] arr=set.toArray();
			Arrays.sort(arr);
			int length=arr.length;
			for(int i=0;i<length;i++){
			    for(int j=0;j<length-1-i;j++)
			    {
				if(wordMap.get(arr[j])<wordMap.get(arr[j+1]))
				{
				    Object temp=arr[j+1];
				    arr[j+1]=arr[j];
				    arr[j]=temp;
				}
			    }
			}
			for (Object key:arr) {
					System.out.println(key+" "+wordMap.get(key));
				}
			System.out.println("final word number: "+wordMap.size());
		} catch(Exception e){;}
	}

	public static void main(String[] args) throws IOException {
		try {
		    ReadFile=args[0];
			long t0=System.currentTimeMillis();
			slaveOn("./a.txt");
			long t1=System.currentTimeMillis();

			maping();
			long t2=System.currentTimeMillis();

			shuffling();
			long t3=System.currentTimeMillis();

			reduces();
			long t4=System.currentTimeMillis();
			sort();
			long t5=System.currentTimeMillis();
			System.out.println("distribution time cost: "+(t1-t0)/1000+"s");
			System.out.println("maping time cost: "+(t2-t1)/1000+"s");
			System.out.println("shuffling time cost: "+(t3-t2)/1000+"s");
			System.out.println("reduce time cost: "+(t4-t3)/1000+"s");
			System.out.println("total time cost: "+(t5-t0)/1000+"s");

		} catch(Exception e){
			e.printStackTrace();
		}
    	}
}
