import  java.lang.Object;
import java.lang.ProcessBuilder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
//import java.io.TimeUnit;


public class Master{
	
	public static String ReadFile="./pri.txt";
	public static int slaveCount = 0;
	public static ArrayList<String> slaveList=new ArrayList<String>();
	

	private static Map<String, Integer> wordMap=new HashMap<String, Integer>();

	public static void readWord(String strFile){
		try {
		    File file = new File(strFile);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null;
		    while(null != (strLine = bufferedReader.readLine())){
		        if(strLine!="^$" && strLine!="\n" && strLine!="\r") mapLine(strLine);
		    }
		}catch(Exception e){
		    e.printStackTrace();
		}
	 }

	    public static void mapLine(String line){
			line=line.replaceAll("[^0-9a-zA-Z\u4e00-\u9fa5]+"," ");
			line = line.replaceAll("^$", " ");
			String[] command = line.split(" ");
		        for(int i=0;i<command.length;i++){
		                String word=command[i];
		                wordMap.put(word,0);
		        }
            }
	    public static void readFileLine(String strFile, int s){
		try {
		    
		    File file0 = new File(strFile);
		    BufferedReader bufferedReader0 = new BufferedReader(new FileReader(file0));
		    String strLine0 = null;
		    double total_row_number=0;
		    while(null != (strLine0 = bufferedReader0.readLine())){
		        if(strLine0!="^$" && strLine0!="\n" && strLine0!="\r") {total_row_number=total_row_number+1;mapLine(strLine0);}
		    }
		    
		    
		    File file = new File(strFile);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null;
		    double file_number = 1;
		    double row_number = 0;
		    //int num=0;
		    FileWriter fw = new FileWriter("S0.txt");
		    while ((strLine = bufferedReader.readLine()) != null) {
			if(strLine0!="^$" && strLine0!="\n" && strLine0!="\r" ){		        
				row_number=row_number+1;
				fw.append(strLine + "\r\n");
				if(row_number/total_row_number>=(file_number) /s){
				    fw.close();
				    if (file_number>=s) return;
				    fw = new FileWriter("S"+(int) file_number+".txt");
				    file_number ++ ;
				}
			}
		    }
		    fw.close();
		    
		}
		catch(Exception e){
		    e.printStackTrace();
		}
	    }	

	public static void slaveOn(String fileName) throws IOException {
		try {
		    File file = new File(fileName);
		    BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
		    String strLine = null; 
		    while(null != (strLine = bufferedReader.readLine())){
		        String[] sla = strLine.split(" ");
			ProcessBuilder pb0 = new ProcessBuilder("nmap",sla[1]);       
			Process process0 = pb0.start();
			process0.waitFor();
			InputStream isI=process0.getInputStream();
			byte[] re=new byte[1024];
			while(isI.read(re)!=-1){
				//System.out.println(new String(re));
				String read=new String(re);
				//String[] slave = read.split(" ");
				int index=read.indexOf("22/tcp");
				if(index!=-1) {
					slaveList.add(strLine);
					slaveCount++;
					break;
				}
			}
			InputStream IsE=process0.getErrorStream();
		 
		    }
		}catch(Exception e){
		    e.printStackTrace();
		}

		ProcessBuilder pb1 = new ProcessBuilder("rm","-rf","maps/");
			Process process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
		
		pb1 = new ProcessBuilder("mkdir","/home/ie/Desktop/maps/");       
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
		
		pb1 = new ProcessBuilder("rm","-rf","/home/ie/Desktop/reduces/");       
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		pb1 = new ProcessBuilder("mkdir","/home/ie/Desktop/reduces/");       
			process1 = pb1.start();
			try {
				process1.waitFor();
				InputStream isI=process1.getInputStream();
				isI.read();
				InputStream IsE=process1.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		System.out.println("number of slave online: "+slaveCount);
		readFileLine(ReadFile, slaveCount);
		//readWord(ReadFile);

		for(int ii=0;ii<slaveList.size();ii++){
			String[] slave=slaveList.get(ii).split(" ");
			String name=slave[0];
			String ip=slave[1];
			ProcessBuilder pb = new ProcessBuilder("ssh",name+"@"+ip,"rm","-rf","/tmp/ie/");       
			Process process = pb.start();
			System.out.println("distribute file to slave "+ii);
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

		  	pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/");       
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
			
			pb = new ProcessBuilder("scp","Slave.jar",name+"@"+ip+":/tmp/ie/");       
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
			
			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/splits/");       
			process = pb.start();
			try {
				process.waitFor();//lave 0 shuffle word : 0 Car

				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
			
			pb = new ProcessBuilder("scp","S"+ii+".txt",name+"@"+ip+":/tmp/ie/splits/");       
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}

			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/maps/");       
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
			
			pb = new ProcessBuilder("ssh",name+"@"+ip,"mkdir","/tmp/ie/reduces/");       
			process = pb.start();
			try {
				process.waitFor();
				InputStream isI=process.getInputStream();
				isI.read();
				InputStream IsE=process.getErrorStream();
				byte[] re=new byte[1024];
				while(isI.read(re)!=-1){
					System.out.println(new String(re));
				}
			} catch(Exception e) {
					e.printStackTrace();
			}
		}
	}


	public static ArrayList<Thread> slaveThread=new ArrayList<Thread>();

	public static void maping(){
		/*
		ArrayList<ProcessBuilder> pb=new ArrayList<ProcessBuilder>();	
		ArrayList<Process> p=new ArrayList<Process>();	
		//ProcessBuilder[] pb[slaveCount];
		//Process[] process[slaveCount];
		for(int ii=0;ii<slaveList.size();ii++){
			String[] slave=slaveList.get(ii).split(" ");
			String name=slave[0];
			String ip=slave[1];
			pb.add(new ProcessBuilder("ssh",name+"@"+ip,"/usr/java/jdk1.8.0_231/bin/java","-jar","/tmp/ie/Slave.jar","0","/tmp/ie/splits/S"+ii+".txt"));       
			
			try {
				//process[ii].waitFor();
				p.add(pb.get(ii).start());
				InputStream isI=p.get(ii).getInputStream();
				isI.read();
				InputStream IsE=p.get(ii).getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}
		for(int ii=0;ii<slaveList.size();ii++){
			while(p.get(ii).isAlive()) {;}
		}

		*/
		try{    

 
			for (int i=0;i<slaveCount;i++){
		            MyThread2 myThread = new MyThread2();
                           
			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    name.add("ssh");
			    name.add(name_slave+"@"+ip);
			    name.add("/usr/java/jdk1.8.0_231/bin/java");
			    name.add("-jar");
			    name.add("/tmp/ie/Slave.jar");
				name.add("0");
				name.add("/tmp/ie/splits/S"+i+".txt");
			    myThread.setName(name);
			    Thread thread = new Thread(myThread);
			    slaveThread.add(thread);
			    //thread.start();
				slaveThread.get(i).start();
				System.out.println("mapping slave "+i);
				//thread.join();
			}
			
			for (int i=0;i<slaveCount;i++){
                            Thread thread = slaveThread.get(i); 
			    while(thread.isAlive()) {;}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
        public static ArrayList<Thread> wordThread=new ArrayList<Thread>();
	public static void shuffling() throws IOException{
		//TimeUnit.SECONDS.sleep(1);
		try{	
			Thread.currentThread().sleep(10000);
			ArrayList<ProcessBuilder> pb=new ArrayList<ProcessBuilder>();	
			ArrayList<Process> p=new ArrayList<Process>();		
			for(int ii=0;ii<slaveList.size();ii++){
				String[] slave=slaveList.get(ii).split(" ");
				String name=slave[0];
				String ip=slave[1];
					pb.add(new ProcessBuilder("scp","-r","maps/",name+"@"+ip+":/tmp/ie/"));       
					try {
						p.add(pb.get(ii).start());				
						//p.get(jj).waitFor();
						System.out.println("send slave "+ii+" all texts ");
						InputStream isI=p.get(ii).getInputStream();
						isI.read();
						InputStream IsE=p.get(ii).getErrorStream();
					} catch(Exception e) {
							e.printStackTrace();
					}
					
			}

			for(int ii=0;ii<slaveList.size();ii++){
				try {
					p.get(ii).waitFor();
				} catch(Exception e) {
						e.printStackTrace();
				}
			}
		} catch(Exception e){;}
		/*

		try{
			for (int i=0;i<slaveCount;i++){
			    MyThread2 myThread = new MyThread2();
			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    name.add("scp");
			    name.add("-r");
			    name.add("maps/");
			    name.add(name_slave+"@"+ip+":/tmp/ie/");
			    //name.add("/tmp/ie/Slave.jar");
				//name.add("0");
				//name.add("/tmp/ie/splits/S"+i+".txt");
			    myThread.setName(name);
			    Thread thread = new Thread(myThread);
			    thread.start();
			thread.join();
			}
		}catch(Exception e){
			e.printStackTrace();MyThread2 myThread = new MyThread2();
		}

*/
		/*
		pb.clear();
		p.clear();
		

		Set set=wordMap.keySet();
		Object[] arr=set.toArray();
		for(int ii=0;ii<wordMap.size();ii++){
			String[] slave=slaveList.get(ii%slaveList.size()).split(" ");
			String name=slave[0];
			String ip=slave[1];
			wordMap.put(arr[ii].toString(),ii%slaveList.size());
			ArrayList<String> cmd=new ArrayList<String>();
			cmd.add("ssh");
			cmd.add(name+"@"+ip);
			cmd.add("/usr/java/jdk1.8.0_231/bin/java");
			cmd.add("-jar");
			cmd.add("/tmp/ie/Slave.jar");
			cmd.add("1");
			cmd.add(arr[ii].toString());
			cmd.add("/tmp/ie/maps/SM"+ii+".txt");
			for (int jj=0;jj<slaveList.size();jj++){
				
				cmd.add("/tmp/ie/maps/UM"+jj+".txt");
			}      
			pb.add(new ProcessBuilder(cmd));
			try {
				//process[ii].waitFor();
				System.out.println("slave "+ii%slaveCount+" shuffle word : "+ii+" "+arr[ii].toString());
				p.add(pb.get(ii).start());
				InputStream isI=p.get(ii).getInputStream();
				isI.read();
				InputStream IsE=p.get(ii).getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			} 
		}*/
		
		try{
			Set set=wordMap.keySet();
			Object[] arr=set.toArray();
			int wait_time=0;
			for (int i=0;i<wordMap.size();i++){
				Thread.currentThread().sleep(20);
			    if( i%1000==0) wait_time = 20;
 
			
			   Thread.currentThread().sleep(wait_time);
			    if(i>=1500 && i%200==0 ) Thread.currentThread().sleep(1000);
			    /*
			   if(i>199 && i%200==0){
				for (int j=i-195;j<i-145;j++){
		                    Thread thread = slaveThread.get(j); 
				    while(thread.isAlive()) {Thread.currentThread().sleep(2000);}
				}
			    }*/
					
			    MyThread2 myThread = new MyThread2();
			    ArrayList<String> name=new ArrayList<String>();
			    String[] slave=slaveList.get(i%slaveCount).split(" ");
				String name_slave=slave[0];
				String ip=slave[1];
			    	name.add("ssh");
				name.add(name_slave+"@"+ip);
				name.add("/usr/java/jdk1.8.0_231/bin/java");
				name.add("-jar");
				name.add("/tmp/ie/Slave.jar");
				name.add("1");
				name.add(arr[i].toString());
				
				name.add("/tmp/ie/maps/SM"+i+".txt");
				name.add(String.valueOf(i%slaveCount));
			for (int jj=0;jj<slaveList.size();jj++){
				
				name.add("/tmp/ie/maps/UM"+jj+".txt");
			}      
			    myThread.setName(name);
			    Thread thread = new Thread(myThread);
			    wordThread.add(thread);
			    //thread.start();
			    //if(i>=1500) wordThread.get(i-1024).join();
			    wordThread.get(i).start();
				System.out.println("slave "+i+" shuffle");
			    
			    //thread.join();
			}
			
			/*
			for (int i=0;i<wordMap.size();i++){
                            Thread thread = wordThread.get(i); 
			    while(thread.isAlive()) {;}
			}*/
		}catch(Exception e){
			;
		}
		/*
		for(int ii=0;ii<wordMap.size();ii++){
			while(p.get(ii).isAlive()) {;}
		}*/
		/*
		for(int ii=0;ii<wordMap.size();ii++){
			try {
				p.get(ii).waitFor();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}*/
		/*
		for(int ii=0;ii<wordMap.size();ii++){
			while(p.get(ii).isAlive()) {;}
		}*/
		/*
		pb.clear();
		p.clear();
		for(int ii=0;ii<wordMap.size();ii++){
			String[] slave=slaveList.get(ii%slaveCount).split(" ");
			String name=slave[0];
			String ip=slave[1];
			//System.out.println("asf"+ii);
			pb.add(new ProcessBuilder("ssh",name+"@"+ip,"scp","/tmp/ie/reduces/RM"+ii+".txt","ie@192.168.1.199:Desktop/reduces/"));       
			try {
				p.add(pb.get(ii).start());
				//System.out.println("abc"+ii);
				InputStream isI=p.get(ii).getInputStream();
				isI.read();
				InputStream IsE=p.get(ii).getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}
		for(int ii=0;ii<slaveList.size();ii++){
			try {
				p.get(ii).waitFor();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}	*/					
	}
	

	public static void reduces(){
		try{    
			ArrayList<ProcessBuilder> pb=new ArrayList<ProcessBuilder>();	
			ArrayList<Process> p=new ArrayList<Process>();	
			Thread.currentThread().sleep(15000);
			for(int ii=0;ii<slaveList.size();ii++){
				String[] slave=slaveList.get(ii).split(" ");
				String name=slave[0];
				String ip=slave[1];
					pb.add(new ProcessBuilder("ssh",name+"@"+ip,"/usr/java/jdk1.8.0_231/bin/java","-jar","/tmp/ie/Slave.jar","2"));       
					try {
						p.add(pb.get(ii).start());				
						p.get(ii).waitFor();
						System.out.println("slave "+ii+" reduce");
						InputStream isI=p.get(ii).getInputStream();
						isI.read();
						InputStream IsE=p.get(ii).getErrorStream();
					} catch(Exception e) {
							e.printStackTrace();
					}	
			}
		} catch(Exception e ){;}
		/*
		for(int ii=0;ii<slaveList.size();ii++){
			while(p.get(ii).isAlive()) {;}
		}*/
		/*	
		Set set=wordMap.keySet();
		Object[] arr=set.toArray();
		for(int ii=0;ii<wordMap.size();ii++){
			String[] slave=slaveList.get(ii%slaveList.size()).split(" ");
			String name=slave[0];
			String ip=slave[1];
			wordMap.put(arr[ii].toString(),ii%slaveList.size());
			ArrayList<String> cmd=new ArrayList<String>();
			cmd.add("ssh");
			cmd.add(name+"@"+ip);
			cmd.add("/usr/java/jdk1.8.0_231/bin/java");
			cmd.add("-jar");
			cmd.add("/tmp/ie/Slave.jar");
			cmd.add("2");
			cmd.add(arr[ii].toString());
			cmd.add("/tmp/ie/maps/SM"+ii+".txt");
			cmd.add("/tmp/ie/reduces/RM"+ii+".txt");
     
			pb.add(new ProcessBuilder(cmd));
			try {
				//process[ii].waitFor();
				System.out.println("slave "+ii%slaveCount+" reduce word : "+ii+" "+arr[ii].toString());
				p.add(pb.get(ii).start());
				InputStream isI=p.get(ii).getInputStream();
				isI.read();
				InputStream IsE=p.get(ii).getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			} 
		}
		for(int ii=0;ii<wordMap.size();ii++){
			try {
				p.get(ii).waitFor();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}


		pb.clear();
		p.clear();
		for(int ii=0;ii<wordMap.size();ii++){
			String[] slave=slaveList.get(ii%slaveCount).split(" ");
			String name=slave[0];
			String ip=slave[1];
			//System.out.println("asf"+ii);
			pb.add(new ProcessBuilder("ssh",name+"@"+ip,"scp","/tmp/ie/reduces/RM"+ii+".txt","ie@192.168.1.199:Desktop/reduces/"));       
			try {
				p.add(pb.get(ii).start());
				//System.out.println("abc"+ii);
				InputStream isI=p.get(ii).getInputStream();
				isI.read();
				InputStream IsE=p.get(ii).getErrorStream();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}
		for(int ii=0;ii<slaveList.size();ii++){
			try {
				p.get(ii).waitFor();
			} catch(Exception e) {
					e.printStackTrace();
			}
		}			
	
		*/
	} 
	
	
	public static void readFileLine1(String strFile){
        try {
            File file = new File(strFile);
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String strLine = null;
            while(null != (strLine = bufferedReader.readLine())){
                mapLine1(strLine);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    	public static void mapLine1(String line){
        	String[] command = line.split(" ");
		String key=command[0];
		int value=Integer.parseInt(command[1]);
                wordMap.put(key,value);
    	}

	public static void sort(){
		try{
			Thread.currentThread().sleep(5000);		
			//int length1=wordMap.size();
			//int length1=8201;
			wordMap.clear();
			for(int ii=0;ii<slaveList.size();ii++){
				readFileLine1("reduces/RM"+ii+".txt");
				System.out.println(ii);
			}
			Set set=wordMap.keySet();
			Object[] arr=set.toArray();
			Arrays.sort(arr);
			int length=arr.length;
			for(int i=0;i<length;i++){
			    for(int j=0;j<length-1-i;j++)
			    {
				if(wordMap.get(arr[j])<wordMap.get(arr[j+1]))
				{
				    Object temp=arr[j+1];
				    arr[j+1]=arr[j];
				    arr[j]=temp;
				}
			    }
			}
			for (Object key:arr) {
					System.out.println(key+" "+wordMap.get(key));
				}
			System.out.println("final word number: "+wordMap.size());
		} catch(Exception e){;}
	}

	public static void main(String[] args) throws IOException {
		try {		
			long t0=System.currentTimeMillis();			
			slaveOn("./a.txt");
			long t1=System.currentTimeMillis();
			
			System.out.println("number of words "+wordMap.size());
			maping();
			long t2=System.currentTimeMillis();
			
			shuffling();
			long t3=System.currentTimeMillis();
			
			reduces();
			long t4=System.currentTimeMillis();
			sort();
			long t5=System.currentTimeMillis();
			System.out.println("distribution time cost: "+(t1-t0)/1000+"s");
			System.out.println("maping time cost: "+(t2-t1)/1000+"s");
			System.out.println("shuffling time cost: "+(t3-t2)/1000+"s");
			System.out.println("reduce time cost: "+(t4-t3)/1000+"s");
			System.out.println("total time cost: "+(t5-t0)/1000+"s");
		} catch(Exception e){
			e.printStackTrace();
		}
    	}
}
